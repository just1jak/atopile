# Rev D series isolation bench prototype

Four layers, 110 x 96 mm, nominal 1.6 mm. Use the four Gerber copper layers in the order F.Cu, In1.Cu, In2.Cu, B.Cu. Confirm stackup and impedance with the fabricator. Use the separate plated and nonplated drill files.

Fill, copper cap and planarize all 254 sites in the via CSV. Coordinates use the KiCad board origin and positive Y down. Confirm the coordinate conversion and processing with the fabricator.

This package contains bare PCB fabrication data and paste artwork. Vehicle use requires bench qualification of contact timing, the single-relay fault cases, and transmit window expiry. See the Rev D README.
