# Rev D assembly quote inputs

Bench prototype only. Use the assembly BOM/CPL together with the included unchanged Rev D Gerbers.
See assembly/README.md for the Omron compatibility decision, assembly exclusions and qualifications.
See assembly/quote-status.md for current quote limitations. No order or stock reservation is included.
PCB: 110 x 96 mm, four layers, 1.6 mm, both-side assembly; 254 mandatory filled/capped/planarized sites.
JLC adds temporary assembly rails. Review actual stackup, process and part placement before ordering.
The original manufacturing notes and historical KiCad reports remain unchanged; fresh reports are in evidence/.
